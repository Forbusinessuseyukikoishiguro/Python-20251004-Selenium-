"""コマンド実行時のエラー"""
import subprocess

subprocess.run(['lsa'])