"""中身が空のファイルを作成する"""
import pathlib

pathlib.Path('empty.txt').touch()