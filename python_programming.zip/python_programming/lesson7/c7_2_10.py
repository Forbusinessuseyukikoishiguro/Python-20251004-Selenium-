"""シンボリックリンクを作成する"""
import os
os.symlink('renamed.txt', 'symlink.txt')