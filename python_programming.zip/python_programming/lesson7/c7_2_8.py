"""ディレクトリかどうかを確認する"""
import os
print(os.path.isdir('design'))