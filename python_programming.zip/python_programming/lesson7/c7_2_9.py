"""ファイル名を変更する"""
import os
os.rename('test.txt', 'renamed.txt')