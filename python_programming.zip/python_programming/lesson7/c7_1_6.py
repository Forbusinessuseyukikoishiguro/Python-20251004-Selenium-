"""with文でファイルをopenする"""
with open('test.txt', 'w') as f:
    f.write('Test')