"""エポックタイム"""
import time

print(time.time())