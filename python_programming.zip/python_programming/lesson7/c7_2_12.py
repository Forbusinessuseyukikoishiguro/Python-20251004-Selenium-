"""ディレクトリを削除する"""
import os
os.rmdir('test_dir')