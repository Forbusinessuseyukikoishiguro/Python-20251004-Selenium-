"""オプションを指定したコマンドの実行"""
import subprocess

subprocess.run(['ls', '-al'])