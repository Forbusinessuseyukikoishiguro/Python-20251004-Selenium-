"""sleep"""
import time

print('#####')
time.sleep(2)
print('#####')