"""ファイルを作成して書き込む"""
f = open('test.txt', 'a')
f.write('Test')
f.close()