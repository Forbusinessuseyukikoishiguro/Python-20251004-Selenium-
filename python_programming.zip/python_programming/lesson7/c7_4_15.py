"""時間の表示"""
import datetime

now = datetime.datetime.now()
print(now)
print(now.isoformat())