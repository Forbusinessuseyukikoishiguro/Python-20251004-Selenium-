"""ファイルを削除する"""
import os

os.remove('empty.txt')