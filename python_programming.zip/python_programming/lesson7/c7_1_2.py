"""ファイルを作成して書き込む"""
f = open('test.txt', 'w')
f.write('Test')
f.close()