"""ファイルを読み込む"""
with open('test.txt', 'r') as f:
    print(f.read())