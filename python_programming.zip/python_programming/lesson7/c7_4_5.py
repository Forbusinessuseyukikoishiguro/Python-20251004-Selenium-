"""コマンドの実行"""
import subprocess

subprocess.run(['ls'])