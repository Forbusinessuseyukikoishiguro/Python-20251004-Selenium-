"""osライブラリを使ったコマンドの実行"""
import os

os.system('ls')