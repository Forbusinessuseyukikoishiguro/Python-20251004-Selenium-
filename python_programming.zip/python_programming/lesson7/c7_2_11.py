"""ディレクトリを作成する"""
import os
os.mkdir('test_dir')