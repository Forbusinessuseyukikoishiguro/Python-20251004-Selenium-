"""ディレクトリの中身ごと削除"""
import shutil

shutil.rmtree('test_dir')