"""enumerate関数"""
for i, fruit in enumerate(['apple', 'banana', 'orange']):
    print(i, fruit)