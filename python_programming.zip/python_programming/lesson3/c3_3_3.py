"""break文"""
count = 0
while True:
    if count >= 5:
        break

    print(count)
    count += 1