"""==によるNoneであるかどうかの判定"""
is_empty = None

if is_empty == None:
    print('None!!!')