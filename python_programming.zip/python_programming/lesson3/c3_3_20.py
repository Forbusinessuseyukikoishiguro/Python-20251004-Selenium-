"""range関数の活用"""
for i in range(10):
    print('hello')