"""リストが空だった場合のifの判定"""
is_ok = []

if is_ok:
    print('OK!')
else:
    print('No!')