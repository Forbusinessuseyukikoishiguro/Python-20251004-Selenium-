"""変数に0が入っていた場合のifの判定"""
is_ok = 0

if is_ok:
    print('OK!')
else:
    print('No!')