"""isによる比較"""
print(None is None)