"""elif文"""
x = 0

if x < 0:
    print('negative')
elif x == 0:
    print('zero')
else:
    print('positive')