"""for else文"""
for fruit in['apple', 'banana', 'orange']:
    print(fruit)
else:
    print('I ate all.')