"""==による比較"""
print(1 == True)