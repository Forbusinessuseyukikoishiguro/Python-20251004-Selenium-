"""インデックス番号を表示する"""
i = 0
for fruit in ['apple', 'banana', 'orange']:
    print(i, fruit)
    i += 1