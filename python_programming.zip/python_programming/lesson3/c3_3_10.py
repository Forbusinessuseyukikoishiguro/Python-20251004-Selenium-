"""for文でリストの中身を取り出す"""
some_list = [1, 2, 3, 4, 5]

for i in some_list:
    print(i)