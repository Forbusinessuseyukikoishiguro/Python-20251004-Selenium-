"""論理演算子 and"""
a = 2
b = 2
if a > 0 and b > 0:
    print('a and b are positive')