"""ネストしたif文のインデント"""
a = 5
b = 10

if a > 0:
    print('a is positive')
     if b > 0:
        print('b is positive')