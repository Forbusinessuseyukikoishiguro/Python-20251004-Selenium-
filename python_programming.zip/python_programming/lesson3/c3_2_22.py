"""Boolean型の変数をnotで否定する"""
is_ok = True

if not is_ok:
    print('hello')