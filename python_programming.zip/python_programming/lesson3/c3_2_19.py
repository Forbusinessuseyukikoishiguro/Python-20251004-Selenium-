"""not"""
a = 1
b = 10

if not a == b:
    print('Not equal')