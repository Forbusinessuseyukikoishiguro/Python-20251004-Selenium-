"""for文とcontinue文"""
for word in ['My', 'name', 'is', 'Mike']:
    if word == 'name':
        continue
    print(word)