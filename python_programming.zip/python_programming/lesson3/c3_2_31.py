"""lenを使ったリストの中身の判定"""
is_ok = [1, 2, 3, 4]

if len(is_ok) > 0:
    print('OK!')
else:
    print('No!')