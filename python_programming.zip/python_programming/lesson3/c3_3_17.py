"""range関数"""
for i in range(10):
    print(i)