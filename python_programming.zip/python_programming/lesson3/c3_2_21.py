"""Boolean型の変数をそのままif文に書く"""
is_ok = True

if is_ok:
    print('hello')