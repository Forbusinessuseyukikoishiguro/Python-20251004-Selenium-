"""items()の中身を確認する"""
d = {'x': 100, 'y': 200}

print(d.items())