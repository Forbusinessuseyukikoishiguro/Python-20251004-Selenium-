"""range関数で数値をとばして取り出す"""
for i in range(2, 10, 3):
    print(i)