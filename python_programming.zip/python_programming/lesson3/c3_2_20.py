"""notではなく!="""
a = 1
b = 10

if a != b:
    print('Not equal')