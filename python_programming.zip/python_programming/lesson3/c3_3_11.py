"""for文で文字列を取り出す"""
for s in 'abcde':
    print(s)

for word in ['My', 'name', 'is', 'Mike']:
    print(word)