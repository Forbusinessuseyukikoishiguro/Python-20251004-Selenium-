"""while else文"""
count = 0

while count < 5:
    print(count)
    count += 1
else:
    print('Done')