"""論理演算子 or"""
a = 1
b = -1
# a > 0またはb > 0が真であれば真
if a > 0 or b > 0:
    print('a or b are positive')