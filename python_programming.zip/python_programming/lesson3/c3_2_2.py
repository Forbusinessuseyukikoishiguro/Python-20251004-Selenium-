"""if文の条件にあてはまらない場合"""
x = 10

if x < 0:
    print('negative')