"""for文とbreak文"""
for word in ['My', 'name', 'is', 'Mike']:
    if word == 'name':
        break
    print(word)