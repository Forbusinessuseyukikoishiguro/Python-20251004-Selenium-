"""not"""
y = [1, 2, 3]
x = 1

if 100 not in y:
    print('not in')