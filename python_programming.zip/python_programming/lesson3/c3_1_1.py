"""コメント"""
print('XXXXX')
# test
print('XXXXX')