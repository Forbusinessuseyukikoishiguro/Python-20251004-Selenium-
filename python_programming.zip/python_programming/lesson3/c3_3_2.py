"""break文"""
count = 0
while True:
    print('XXX')