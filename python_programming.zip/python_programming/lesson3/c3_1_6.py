"""()による行の分割"""
s = ('aaaaaaaaaaa'
    + 'bbbbbbbbb')
print(s)
x = (1 + 1 + 1 + 1 + 1 + 1 + 1
    + 1 + 1 + 1 + 1 + 1 + 1 + 1)
print(x)