"""変数に文字列が入っていた場合のifの判定"""
is_ok = ''

if is_ok:
    print('OK!')
else:
    print('No!')