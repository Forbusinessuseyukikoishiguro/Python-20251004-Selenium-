"""range関数の活用"""
for _ in range(10):
    print('hello')