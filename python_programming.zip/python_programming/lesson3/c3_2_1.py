"""if文"""
x = -10

if x < 0:
    print('negative')