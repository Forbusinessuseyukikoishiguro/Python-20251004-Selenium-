"""isによる比較"""
print(1 is True)
print(True is True)