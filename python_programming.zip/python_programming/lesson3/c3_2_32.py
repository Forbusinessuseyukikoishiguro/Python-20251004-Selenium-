"""Noneをhelpで確認する"""
is_empty = None
print(help(is_empty))