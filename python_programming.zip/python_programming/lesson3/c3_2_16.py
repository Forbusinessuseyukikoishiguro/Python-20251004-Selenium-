"""orを使わない場合"""
a = 1
b = -1
# a > 0またはb > 0が真であれば真
if a > 0:
    print('a or b are positive')
elif b > 0:
    print('a or b are positive')