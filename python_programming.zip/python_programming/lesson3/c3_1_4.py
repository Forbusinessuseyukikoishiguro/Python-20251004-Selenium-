"""変数の説明"""
some_value = 100 # Apple price