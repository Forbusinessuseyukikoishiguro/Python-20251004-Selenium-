"""リストに要素が入っていた場合のifの判定"""
is_ok = [1, 2, 3, 4]

if is_ok:
    print('OK!')
else:
    print('No!')