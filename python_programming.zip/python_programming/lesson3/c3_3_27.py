"""辞書をfor文で処理する"""
d = {'x': 100, 'y': 200}

for k, v in d.items():
    print(k, ':', v)