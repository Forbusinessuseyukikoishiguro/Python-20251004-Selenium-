"""andを使わない場合"""
a = 2
b = 2
# a > 0もb > 0も真であれば真
if a > 0:
    if b > 0:
        print('a and b are positive')