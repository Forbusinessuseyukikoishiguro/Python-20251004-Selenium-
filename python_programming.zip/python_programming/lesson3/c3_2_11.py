"""比較演算子 <"""
a = 1
b = 2
print(a < b)