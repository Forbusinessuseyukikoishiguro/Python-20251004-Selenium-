"""数値を1つずつ出力する"""
num_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

for i in num_list:
    print(i)