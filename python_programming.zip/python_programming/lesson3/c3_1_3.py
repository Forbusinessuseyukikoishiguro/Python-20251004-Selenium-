"""変数の説明"""
# Apple price
some_value = 100