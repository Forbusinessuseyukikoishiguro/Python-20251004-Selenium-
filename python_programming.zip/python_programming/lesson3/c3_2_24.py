"""変数に数値が入っていた場合のifの判定"""
is_ok = 1

if is_ok:
    print('OK!')
else:
    print('No!')