"""in"""
y = [1, 2, 3]
x = 1

if x in y:
    print('in')