"""辞書をfor文で処理する"""
d = {'x': 100, 'y': 200}

for v in d:
    print(v)