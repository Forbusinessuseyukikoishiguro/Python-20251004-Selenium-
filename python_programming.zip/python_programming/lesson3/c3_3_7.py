"""input関数"""
while True:
    word = input('Enter:')
    if word == 'ok':
        break
    print('next')