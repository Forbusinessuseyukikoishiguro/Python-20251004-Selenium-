"""Noneではないことの判定"""
is_empty = None

if is_empty is not None:
    print('None!!!')