"""range関数で開始位置を指定する"""
for i in range(2, 10):
    print(i)