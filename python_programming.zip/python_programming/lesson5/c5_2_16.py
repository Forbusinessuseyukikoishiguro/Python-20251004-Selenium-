"""複数のライブラリのインポート"""
import collections
import os
import sys

import termcolor

import lesson_package