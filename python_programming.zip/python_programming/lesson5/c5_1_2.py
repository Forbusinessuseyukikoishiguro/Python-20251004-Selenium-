"""引数を表示する"""
import sys

print(sys.argv)