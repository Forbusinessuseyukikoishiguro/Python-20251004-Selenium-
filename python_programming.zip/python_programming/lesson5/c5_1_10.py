"""アスタリスクを使ったモジュールの読み込み"""
from lesson_package.talk import *

print(animal.sing())
print(animal.cry())
