"""関数だけをインポートする"""
from lesson_package.utils import say_twice

r = say_twice('hello')
print(r)