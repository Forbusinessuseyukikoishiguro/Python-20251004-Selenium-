"""複数のライブラリのインポート"""
import collections, sys, os