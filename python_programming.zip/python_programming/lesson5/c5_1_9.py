"""関数の呼び出し"""
from lesson_package.talk import human

print(human.cry())