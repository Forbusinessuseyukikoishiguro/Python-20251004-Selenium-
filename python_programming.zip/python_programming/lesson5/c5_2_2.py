"""辞書型のキーを表示する"""

ranking = {
    'A': 100,
    'B': 85,
    'C': 92
}

for key in ranking:
    print(key)