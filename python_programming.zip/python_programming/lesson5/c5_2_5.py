"""get"""
ranking = {
    'A': 100,
    'B': 85,
    'C': 92
}

print(ranking.get('A'))