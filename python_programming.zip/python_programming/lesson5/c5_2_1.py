"""globals()"""

print(globals())