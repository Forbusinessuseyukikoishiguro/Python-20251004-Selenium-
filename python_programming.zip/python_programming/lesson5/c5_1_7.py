""""asを使って読み込む"""
from lesson_package import utils as u

r = u.say_twice('hello')
print(r)