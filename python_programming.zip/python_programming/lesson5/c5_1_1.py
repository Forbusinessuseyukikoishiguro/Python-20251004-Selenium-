"""printの処理を記述"""
print('test')