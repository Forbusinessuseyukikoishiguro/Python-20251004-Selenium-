"""モジュールの読み込み"""
from lesson_package.talk import human

print(human.sing())