"""fromを使ったモジュールの読み込み"""
from lesson_package import utils

r = utils.say_twice('hello')
print(r)