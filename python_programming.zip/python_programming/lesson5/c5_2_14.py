"""複数のライブラリのインポート"""
import collections
import os
import sys