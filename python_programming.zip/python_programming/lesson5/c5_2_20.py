"""__name__の表示"""
print(__name__)