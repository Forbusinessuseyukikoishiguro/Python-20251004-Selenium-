"""animal.pyの読み込み"""
import lesson_package.talk.animal

print('lesson:', __name__)