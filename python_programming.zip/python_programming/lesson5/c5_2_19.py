"""python側がパッケージを読み込む場所を表示"""
import sys

print(sys.path)