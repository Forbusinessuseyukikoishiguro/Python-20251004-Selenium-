"""スクリプトの処理"""
import sys

for i in sys.argv:
    print(i)