"""サードパーティライブラリの関数の使い方を確認する"""
from termcolor import colored

print(help(colored))