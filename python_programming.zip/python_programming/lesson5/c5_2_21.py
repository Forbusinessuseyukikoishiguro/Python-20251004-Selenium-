"""config.pyの読み込み"""
import config

print('lesson:', __name__)