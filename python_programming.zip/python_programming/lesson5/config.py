"""__name__の出力"""
print('config:', __name__)