"""インポートした関数の呼び出し"""
import lesson_package.utils

r = lesson_package.utils.say_twice('hello')
print(r)
