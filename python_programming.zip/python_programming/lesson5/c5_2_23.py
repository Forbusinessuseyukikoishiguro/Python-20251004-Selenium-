"""main関数を使った書き方"""
import lesson_package.talk.animal

def main():
    lesson_package.talk.animal.sing()

if __name__ == '__main__':
    main()