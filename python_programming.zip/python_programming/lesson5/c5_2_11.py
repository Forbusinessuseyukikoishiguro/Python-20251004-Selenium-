"""出力する文字の色を赤くする"""
from termcolor import colored

print(colored('test', 'red'))