"""果物の値段を辞書で作成"""
fruits = {
    'apple': 100,
    'banana': 200,
    'orange': 300
}

print(fruits['apple'])