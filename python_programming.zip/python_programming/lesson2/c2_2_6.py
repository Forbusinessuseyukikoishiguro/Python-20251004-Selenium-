"""変数の入れ替え"""
a = 100
b = 200
print(a, b)
a, b = b, a
print(a, b)