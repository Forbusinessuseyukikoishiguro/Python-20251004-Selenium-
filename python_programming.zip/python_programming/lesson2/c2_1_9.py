"""joinメソッド"""
s = 'My name is Mike.'
to_split = s.split(' ')
print(to_split)
x = ' '.join(to_split)
print(x)