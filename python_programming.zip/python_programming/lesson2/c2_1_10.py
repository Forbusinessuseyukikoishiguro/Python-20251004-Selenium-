"""help関数"""
print(help(list))