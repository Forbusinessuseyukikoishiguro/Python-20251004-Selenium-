"""選択問題の作成"""
choose_from_three = ('A', 'B', 'C')

answer = []

answer.append('A')
answer.append('C')

print(choose_from_three)
print(answer)