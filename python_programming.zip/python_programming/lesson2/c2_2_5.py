"""変数の入れ替え"""
i = 10
j = 20
tmp = i
i = j
j = tmp
print(i, j)