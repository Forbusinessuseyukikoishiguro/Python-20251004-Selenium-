"""リストから重複を削除する"""
f = ['apple', 'banana', 'apple', 'banana']
kind = set(f)
print(kind)