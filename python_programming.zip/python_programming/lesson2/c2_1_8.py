"""splitメソッド"""
s = 'My name is Mike.'
to_split = s.split('!!!')
print(to_split)