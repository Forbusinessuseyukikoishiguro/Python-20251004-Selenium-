"""オブジェクトidの確認"""
X = 20
Y = X
Y = 5
print(id(X))
print(id(Y))
print(Y)
print(X)