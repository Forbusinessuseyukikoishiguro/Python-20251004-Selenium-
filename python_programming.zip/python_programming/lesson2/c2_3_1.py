"""辞書のコピー（代入）"""
x = {'a': 1}
y = x
y['a'] = 1000
print(x)
print(y)