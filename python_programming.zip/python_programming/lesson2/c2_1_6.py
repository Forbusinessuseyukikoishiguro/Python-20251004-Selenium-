"""逆順のソート"""
r = [1, 2, 3, 4, 5, 1, 2, 3]
r.sort()
print(r)
r.sort(reverse=True)
print(r)
r.reverse()
print(r)