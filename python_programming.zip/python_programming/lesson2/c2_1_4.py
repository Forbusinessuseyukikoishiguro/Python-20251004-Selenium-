"""in演算子による包含判定"""
r = [1, 2, 3, 4, 5, 1, 2, 3]
if 5 in r:
    print('exist')