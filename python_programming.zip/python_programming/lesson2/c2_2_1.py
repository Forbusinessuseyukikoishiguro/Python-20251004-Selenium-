"""タプルのアンパッキング"""
num_tuple = (10, 20)
x, y = num_tuple
print(x, y)