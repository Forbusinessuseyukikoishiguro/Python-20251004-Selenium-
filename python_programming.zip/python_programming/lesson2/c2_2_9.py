"""選択問題の作成"""
choose_from_three = ('A', 'B', 'C')

answer = []

choose_from_three.append('A')
choose_from_three.append('C')