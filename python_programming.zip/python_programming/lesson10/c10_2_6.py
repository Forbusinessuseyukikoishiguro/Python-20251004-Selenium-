"""ファイルにログを出力"""
import logging

logging.basicConfig(filename='test.log', level=logging.INFO)

logging.info('info %s %s', 'test', 'test2')