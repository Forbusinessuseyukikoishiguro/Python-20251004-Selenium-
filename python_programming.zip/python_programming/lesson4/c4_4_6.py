"""ローカル変数を出力する"""
def f():
    animal = 'dog'
    print('local:', locals())

f()