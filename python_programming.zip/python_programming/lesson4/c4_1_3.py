""""関数の呼び出し方"""
def say_something():
    print('hi')
say_something
