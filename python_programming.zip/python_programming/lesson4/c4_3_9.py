"""集合内包表記"""
s = {i for i in range(10)}
print(s)