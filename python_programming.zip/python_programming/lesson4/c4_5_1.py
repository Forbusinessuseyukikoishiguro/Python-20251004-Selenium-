"""IndexError"""
l = [1, 2, 3]
i = 5
l[i]