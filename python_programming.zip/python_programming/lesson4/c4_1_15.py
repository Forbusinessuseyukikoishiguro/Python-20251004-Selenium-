"""キーワード引数"""
def menu(entree, drink, dessert):
    print('entree = ', entree)
    print('drink = ', drink)
    print('dessert = ', dessert)

menu(entree='beef', dessert='ice', drink='beer')