"""内包表記でタプルを作成する"""
g = tuple(i for i in range(10))
print(type(g))
print(g)