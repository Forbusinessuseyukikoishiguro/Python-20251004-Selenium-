"""イテレーター"""
l = ['Good morning', 'Good afternoon', 'Good night']

for i in l:
    print(i)