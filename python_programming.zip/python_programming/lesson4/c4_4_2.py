"""関数内からグローバル変数を呼び出す"""
animal = 'cat'

def f():
    print(animal)

f()