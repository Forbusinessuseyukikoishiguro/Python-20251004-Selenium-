""""関数の型"""
def say_something():
    print('hi')

print(type(say_something))
