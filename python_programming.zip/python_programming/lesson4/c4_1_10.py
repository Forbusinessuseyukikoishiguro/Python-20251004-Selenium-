"""返り値の型の宣言"""
def add_num(a: int, b: int) -> int:
    return a + b