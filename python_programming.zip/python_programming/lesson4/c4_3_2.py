"""リスト内包表記"""
t = (1, 2, 3, 4, 5)

r = [i for i in t]

print(r)