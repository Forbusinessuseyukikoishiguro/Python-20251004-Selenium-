"""関数を変数に入れて呼び出す"""
def say_something():
    print('hi')

f = say_something
f()