""""
Test Test ###########################
"""
animal = 'cat'

print('global:', globals())