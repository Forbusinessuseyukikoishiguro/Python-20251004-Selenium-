"""raise"""
raise IndexError('test error')