"""タプルから要素を取り出してリストにする"""
t = (1, 2, 3, 4, 5)

r = []
for i in t:
    r.append(i)

print(r)