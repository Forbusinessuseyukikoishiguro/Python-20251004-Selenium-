animal = 'cat'

print('global:', globals())