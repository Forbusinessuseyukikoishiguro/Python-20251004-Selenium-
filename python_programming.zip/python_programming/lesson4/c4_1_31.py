"""キーワード引数の辞書化"""
def menu(**kwargs):
    print(kwargs)

menu(entree='beef', drink='coffee')
