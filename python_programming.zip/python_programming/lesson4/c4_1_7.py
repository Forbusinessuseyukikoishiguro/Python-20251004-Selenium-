"""引数"""
def what_is_this(color):
    print(color)

what_is_this('red')