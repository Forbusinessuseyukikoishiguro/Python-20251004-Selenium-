"""forループで集合を作成する"""
s = set()

for i in range(10):
    s.add(i)

print(s)