"""エラーハンドリング"""
l = [1, 2, 3]
i = 5
try:
    l[i]
except:
    print("Don't worry")

print("last")