"""デフォルト引数を上書きする"""
def menu(entree='beef', drink='wine', dessert='ice'):
    print('entree = ', entree)
    print('drink = ', drink)
    print('dessert = ', dessert)

menu(entree='chicken', drink='beer')
