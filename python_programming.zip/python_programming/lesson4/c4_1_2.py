""""関数定義の順番"""
say_something()
def say_something():
    print('hi')