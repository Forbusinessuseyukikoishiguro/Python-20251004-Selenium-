"""ローカル変数を出力する"""
def f():
    print('local:', locals())

f()