"""グローバル変数"""
animal = 'cat'

print(animal)