"""返り値"""
def say_something():
    s = 'hi'
    return s

result = say_something()
print(result)