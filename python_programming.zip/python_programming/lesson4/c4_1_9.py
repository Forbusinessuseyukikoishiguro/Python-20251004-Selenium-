"""引数の型の宣言"""
def add_num(a: int, b: int):
    return a + b