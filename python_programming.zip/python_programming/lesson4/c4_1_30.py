"""キーワード引数"""
def menu(entree='beef', drink='wine'):
    print(entree, drink)

menu(entree='beef', drink='coffee')