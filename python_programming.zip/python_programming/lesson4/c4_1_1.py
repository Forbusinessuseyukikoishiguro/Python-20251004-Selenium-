""""関数定義"""
def say_something():
    print('hi')

say_something()
