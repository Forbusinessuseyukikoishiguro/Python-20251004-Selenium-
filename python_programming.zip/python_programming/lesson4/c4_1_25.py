"""複数の引数"""
def say_something(word, word2, word3):
    print(word)
    print(word2)
    print(word3)

say_something('Hi!', 'Mike', 'Nancy')

